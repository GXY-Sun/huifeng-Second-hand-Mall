/*
 Navicat Premium Data Transfer

 Source Server         : gxy
 Source Server Type    : MySQL
 Source Server Version : 80040 (8.0.40)
 Source Host           : localhost:3306
 Source Schema         : scfwq

 Target Server Type    : MySQL
 Target Server Version : 80040 (8.0.40)
 File Encoding         : 65001

 Date: 10/05/2025 17:06:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `adid` bigint NOT NULL AUTO_INCREMENT,
  `adpassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `adusername` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  PRIMARY KEY (`adid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, '456', '123');
INSERT INTO `admin` VALUES (2, '222', '111');
INSERT INTO `admin` VALUES (3, 'admin', 'admin');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `image_url` varchar(10000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT '',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `price` double NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `create_time` datetime(6) NULL DEFAULT NULL,
  `merchant_id` bigint NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `auto_off_shelf_time` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (1, '数码家电', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.FTKpKpSnLpZNeoPwAgCG3gHaF3?w=280&h=222&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '大疆相机', 3999, 2, '2025-04-02 23:28:11.000000', 1, '拥有 4/3 CMOS 哈苏相机和双焦段长焦相机，Cine 版三摄更支持 Apple ProRes 编码，具备 43 分钟飞行时间、全向避障、15 公里高清图传等飞行性能，全方位提升专业影像创作体验。', '2025-04-28 19:43:25.000000');
INSERT INTO `goods` VALUES (2, '服饰鞋包', 'https://ts4.tc.mm.bing.net/th/id/OIP-C.GdmGlKQBRZSPUSuYbJiByQAAAA?w=247&h=247&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '哭泣外套', 19999, 2, '2025-04-04 23:28:14.000000', 1, '古驰的外套通常采用高品质的面料，如羊绒、羊毛、皮革等。 羊绒质地柔软，保暖性能好，适合秋冬季节。 羊毛外套则更加耐磨，适合日常穿搭。 皮革外套不仅耐穿，还能彰显独特的个性，是时尚界的常青树。 选择时，可以根据个人喜好和需求来决定。 古驰的外套款式多样，从经典的单排扣风衣到帅气的皮夹克，每一种都能展现出不同的风格。 经典款式的单排扣风衣适合正式场合，简洁大方，百搭不挑人。', '2025-04-27 19:44:45.000000');
INSERT INTO `goods` VALUES (3, '数码家电', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.dJ-uX57Ooa-qrCtxKCQQYQHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '美的空调', 4000, 2, '2025-04-05 23:28:16.000000', 1, '隶属于 美的集团，是集家用、 商用空调 产品开发 、生产、服务于一体的经营平台。 除广东 顺德 总部外，美的空调在广州、 芜湖 、武汉、 邯郸 、重庆建有 生产制造 基地，产品畅销全球150多个 国家和地区，连续7年出口第一。 美的空调的两大核心部件使用的是 GMCC美芝 压缩机 和威灵电机，均为美的集团旗下的全球最大的 空调压缩机 企业和电机公司 ', '2025-04-29 19:45:06.000000');
INSERT INTO `goods` VALUES (4, '食品生鲜', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.hr-U20yVeXtPhlcXsDbeFgHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '德芙巧克力', 40, 2, '2025-04-06 23:28:19.000000', 1, '在巧克力的世界里，德芙巧克力犹如一颗璀璨的明星，散发着独特而迷人的魅力。它不仅是一种美味的零食，更是一种情感的寄托，承载着无数人的甜蜜回忆。', '2025-04-30 19:45:09.000000');
INSERT INTO `goods` VALUES (5, '美妆护肤', 'https://ts2.tc.mm.bing.net/th/id/OIP-C.pEhZbDV3uSXBwj5h19gROwHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', 'ysl口红', 300, 2, '2025-04-01 23:28:21.000000', 2, '质地和舒适度\r\n\r\n丝滑与轻盈 - YSL圣罗兰口红的质地可以用丝滑来形容。 它在涂抹时极为轻盈，几乎感觉不到重量，给人一种天鹅绒般的触感。\r\n滋润与保湿 - 即便是最持久的色号，也能提供足够的滋润感。 YSL口红中的保湿成分如 橄榄油 和 维生素E，有助于保持双唇的滋润，避免干燥和开裂。\r\n无粘腻感 - 与许多其他品牌的口红相比，YSL的产品几乎不会留下粘腻的感觉，这使得长时间佩戴也变得轻松愉悦。', '2025-04-30 19:46:59.000000');
INSERT INTO `goods` VALUES (6, '数码家电', 'https://ts1.tc.mm.bing.net/th/id/OIP-C.55pRSEiGuUG4_8D4UiILhwHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '小米冰箱', 2999, 2, '2025-04-05 23:28:24.000000', 2, '小米冰箱普遍采用“冷藏室+冷冻室+变温室”的三区设计，以520L为例： - 冷藏室（306L）：配备3层玻璃隔板+2个保湿抽屉，适合存放果蔬； - 冷冻室（175L）：4个独立抽屉，支持-24℃深冷速冻； - 变温室（39L）：可在-3℃~5℃间调节，兼顾母婴、冷饮等场景。 优势：冷藏室门架设计较深，可竖放1.5L大瓶装饮料；变温室支持一键母婴模式，适合储存母乳或辅食。', '2025-04-23 19:47:02.000000');
INSERT INTO `goods` VALUES (22, '数码家电', 'https://m.360buyimg.com/mobilecms/s750x750_jfs/t1/71402/39/2245/114189/5d08b22bEd6486101/9063f8aecda2e589.jpg!q80.dpg', '外星人笔记本', 12000, 2, '2025-04-17 19:44:17.361000', 1, '这款16英寸游戏笔记本，设计紧凑，配设隐藏模式，适用各种场景；至高搭载英特尔 ® 酷睿™ Ultra 9 处理器，最高可配 NVIDIA ® GeForce RTX™ 4060 显卡，能在高性能游戏、流媒体等场景下大显身手。 每台 Alienware 外星人笔记本电脑都经过精心设计，旨在智能地管理散热活动以实现出色性能，并特意设置了一系列经过测试的进气口和排气口，可提供您所需的性能。', '2025-04-24 19:47:07.000000');
INSERT INTO `goods` VALUES (23, '服饰鞋包', 'https://ts1.tc.mm.bing.net/th/id/R-C.e43cc0fb67748d3fd80e4ed4541479d7?rik=ZrwR%2fPRslDmNaw&riu=http%3a%2f%2fwww.77lux.com%2fwd-content%2fuploads%2fimages%2f2021%2f11%2f08%2fIMG_211108183416138532.jpg&ehk=hKzam5Zlla%2fTgCnYEOk1EXVqlaSsPywNlYFloCj9x7s%3d&risl=&pid=ImgRaw&r=0', '香奈儿包包', 4999, 2, '2025-04-17 19:58:10.579000', 1, '香奈儿包包的定位明确，主要面向追求时尚、注重品质、崇尚优雅的年轻女性用户群体。 香奈儿的包包不仅是一种奢侈品，更是一种艺术和文化的体现。 香奈儿包包的设计风格独特，融合了经典与现代的设计元素，注重细节和品质。 包包通常采用高品质的材料和精湛的手工艺制作而成，如羊皮、鳄鱼皮等，同时', '2025-04-26 19:47:11.000000');
INSERT INTO `goods` VALUES (25, '美妆护肤', 'https://ts4.tc.mm.bing.net/th/id/OIP-C.a-_f-vGwbVNGqZpQLFnJIAAAAA?w=219&h=219&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '韩束面膜', 49, 1, '2025-04-18 00:54:25.689000', 1, '韩束面膜一盒，一盒10片，便宜甩卖', '2025-04-30 19:47:14.000000');
INSERT INTO `goods` VALUES (43, '数码家电', 'https://iphone-mania.jp/uploads/2023/09/12/iPhone16-KM.jpg', 'iPhone16', 8999, 1, '2025-04-19 05:00:27.203000', 1, '自用99新手机', '2025-04-30 05:01:27.000000');
INSERT INTO `goods` VALUES (44, '食品生鲜', 'https://img.ugoshop.com/images/201611/source_img/79310_P_1479079067885.jpg', '费列罗巧克力', 95, 1, '2025-04-19 05:02:09.393000', 1, '一盒20颗', '2025-04-30 05:03:09.000000');
INSERT INTO `goods` VALUES (45, '美妆护肤', 'https://cbu01.alicdn.com/img/ibank/O1CN017WLtaS1rz6pDfolKs_!!2200736535701-0-cib.jpg', '娇润泉洗面奶', 45, 1, '2025-04-19 05:06:56.991000', 1, '买多了全新未拆封', '2025-04-30 05:07:56.000000');
INSERT INTO `goods` VALUES (46, '数码家电', 'https://ts2.tc.mm.bing.net/th/id/OIP-C.qxuwYr8Z2r0WSjzWCnmFIwHaE8?w=306&h=204&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '罗技鼠标g502', 159, 2, '2025-04-19 07:48:39.225000', 1, '自己使用3个月9成新', '2025-04-30 07:49:39.000000');
INSERT INTO `goods` VALUES (47, '数码家电', 'https://ts4.tc.mm.bing.net/th/id/OIP-C.jbZNL7xBKvt8p6IUkwD9ewHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '狼蛛键盘', 200, 2, '2025-04-19 07:52:26.858000', 1, '全新未使用不想要了', '2025-04-30 07:53:26.000000');
INSERT INTO `goods` VALUES (49, '数码家电', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.VPP3_8KW79B4FpJt6gxnegHaD4?w=345&h=181&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', 'wooting键盘', 1020, 1, '2025-04-19 08:04:41.382000', 1, '自用6个月保养很好9成新', '2025-04-30 08:05:41.000000');
INSERT INTO `goods` VALUES (50, '数码家电', 'https://ts1.tc.mm.bing.net/th/id/OIP-C.HBMO-ZJ564U91TpWnI-qrgHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '红米k80', 4999, 1, '2025-04-19 08:10:05.068000', 1, '全新未拆封', '2025-04-30 08:11:05.000000');
INSERT INTO `goods` VALUES (51, '数码家电', 'https://ts4.tc.mm.bing.net/th/id/OIP-C.MEoSe4VyLvO2Iypq84pPDQHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '罗技gpw1', 299, 2, '2025-04-19 08:20:01.635000', 1, '全新仅拆封', '2025-04-30 08:21:01.000000');
INSERT INTO `goods` VALUES (55, '数码家电', 'https://ts4.tc.mm.bing.net/th/id/OIP-C.SQJmAYkavDaL0w9iaNGBlgHaG1?w=260&h=240&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', '戴尔g15笔记本电脑', 5999, 2, '2025-04-19 09:15:40.959000', 20, '99新买回来体验不佳不想要', '2025-04-26 09:15:40.959000');
INSERT INTO `goods` VALUES (58, '食品生鲜', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.6Eqt_hGycffvGk3g9VmPwgAAAA?w=247&h=247&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', 'on蛋白粉', 420, 2, '2025-04-19 12:49:55.261000', 21, '未拆封保质期只过了5个月', '2025-04-26 12:49:55.261000');
INSERT INTO `goods` VALUES (59, '服饰鞋包', 'https://ts3.tc.mm.bing.net/th/id/OIP-C.dBlhuFZXrq1JCvOw9g2VsQHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', 'nike短袖', 99, 2, '2025-04-19 14:56:39.315000', 22, '99新刚拆封', '2025-04-26 14:56:39.315000');
INSERT INTO `goods` VALUES (60, '食品生鲜', 'https://ts2.tc.mm.bing.net/th/id/OIP-C.VCyLiVZp4OgU9yBq6ZvsdwHaHa?w=298&h=298&c=10&rs=1&bgcl=fffffe&r=0&o=6&pid=23.1', '飞天茅台', 3299, 1, '2025-04-22 07:48:24.543000', 1, '飞天茅台酒是一款 酱香型白酒，采用 高温制曲， 二次投料， 堆积发酵 的 生产工艺，一般一年为一个 生产周期。 取酒后经过勾兑、陈贮而成。 其酒味呈 酱香 、窖底香、醇甜香而具独特风格。 酒体完美，香气幽雅，酒味丰满、醇厚。', '2025-04-29 07:48:24.543000');
INSERT INTO `goods` VALUES (68, '服饰鞋包', 'https://ts2.tc.mm.bing.net/th/id/OIP-C.U1eWA0ShmjMtrhoFDLxiTAHaHa?w=250&h=250&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2', 'aj1鞋子', 999, 2, '2025-04-26 02:14:55.704000', 21, '全新刚拆封', '2025-04-06 09:12:08.408000');

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` bigint NULL DEFAULT NULL,
  `goods_id` bigint NULL DEFAULT NULL,
  `order_time` datetime(6) NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (1, 1, 1, '2025-04-04 14:34:47.000000', 3);
INSERT INTO `order` VALUES (3, 2, 3, '2025-04-04 14:35:21.000000', 2);
INSERT INTO `order` VALUES (4, 2, 4, '2025-04-04 14:35:31.000000', 3);
INSERT INTO `order` VALUES (6, 1, 6, '2025-04-05 17:27:43.000000', 1);
INSERT INTO `order` VALUES (8, 1, 25, '2025-04-18 08:27:58.115000', 0);
INSERT INTO `order` VALUES (11, 1, 45, '2025-04-19 05:09:09.478000', 2);
INSERT INTO `order` VALUES (20, 1, 55, '2025-04-19 09:38:20.746000', 3);
INSERT INTO `order` VALUES (21, 21, 51, '2025-04-19 12:23:35.748000', 3);
INSERT INTO `order` VALUES (24, 22, 47, '2025-04-19 14:57:11.155000', 3);
INSERT INTO `order` VALUES (25, 21, 59, '2025-04-19 15:00:22.252000', 3);
INSERT INTO `order` VALUES (26, 20, 2, '2025-04-20 03:46:35.987000', 2);
INSERT INTO `order` VALUES (27, 1, 51, '2025-04-22 08:17:55.593000', 0);
INSERT INTO `order` VALUES (33, 21, 23, '2025-04-26 02:15:51.999000', 3);

-- ----------------------------
-- Table structure for profit
-- ----------------------------
DROP TABLE IF EXISTS `profit`;
CREATE TABLE `profit`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` double NULL DEFAULT NULL,
  `order_id` int NULL DEFAULT NULL,
  `profit_time` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of profit
-- ----------------------------
INSERT INTO `profit` VALUES (1, 39.9, 1, '2025-04-05 18:47:43.000000');
INSERT INTO `profit` VALUES (2, 199.9, 2, '2025-04-05 18:48:08.000000');
INSERT INTO `profit` VALUES (3, 40, 3, '2025-04-04 18:48:25.000000');
INSERT INTO `profit` VALUES (4, 0.4, 4, '2025-04-01 18:49:03.000000');
INSERT INTO `profit` VALUES (5, 3, 5, '2025-04-14 18:49:18.000000');
INSERT INTO `profit` VALUES (6, 29.9, 6, '2025-04-13 18:49:25.000000');
INSERT INTO `profit` VALUES (10, 199.99, 2, '2025-04-18 15:42:22.389000');
INSERT INTO `profit` VALUES (11, 0.49, 10, '2025-04-18 18:18:11.025000');
INSERT INTO `profit` VALUES (12, 0.45, 12, '2025-04-19 05:13:12.365000');
INSERT INTO `profit` VALUES (13, 0.45, 11, '2025-04-19 07:50:46.297000');
INSERT INTO `profit` VALUES (14, 29.990000000000002, 6, '2025-04-19 08:47:39.395000');
INSERT INTO `profit` VALUES (15, 0.49, 8, '2025-04-19 08:48:20.730000');
INSERT INTO `profit` VALUES (16, 49.99, 15, '2025-04-19 08:51:08.822000');
INSERT INTO `profit` VALUES (17, 0.49, 16, '2025-04-19 09:27:46.921000');
INSERT INTO `profit` VALUES (18, 59.99, 20, '2025-04-19 09:38:41.623000');
INSERT INTO `profit` VALUES (19, 2.99, 21, '2025-04-19 12:44:05.960000');
INSERT INTO `profit` VALUES (20, 0.99, 25, '2025-04-19 15:00:31.129000');
INSERT INTO `profit` VALUES (21, 0.49, 32, '2025-04-26 01:54:52.054000');
INSERT INTO `profit` VALUES (22, 0.99, 25, '2025-04-26 02:17:24.334000');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `card` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `money` double NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `role` int NULL DEFAULT NULL,
  `time` datetime(6) NULL DEFAULT NULL,
  `account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `apply` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '4012300120131026', 1248.51, '张三', '13583491205', 0, '2025-04-02 16:36:10.000000', '123', '河南省新乡市红旗区雷迪森酒店', '456', 0);
INSERT INTO `user` VALUES (2, '0987654321123456', 2463, '李四', '09876543211', 1, '2025-04-10 16:36:44.000000', '111', '河南省新乡市红旗区新乡学院东生活区', '222', 2);
INSERT INTO `user` VALUES (20, '3837295672859403', 6114.010000000002, '王五', '17893295572', 0, '2025-04-19 09:12:22.621000', '123456', '河南省新乡市红旗区河南科技学院', '123456', 1);
INSERT INTO `user` VALUES (21, '2384727382748412', 5045, '张坤', '13874937750', 1, '2025-04-19 12:19:46.289000', 'zhangkun2003', '河南省周口市扶沟县', 'zhangkun2003', 2);
INSERT INTO `user` VALUES (22, '1248128412894128', 696.02, '顾兴宇', '14973004639', 1, '2025-04-19 14:50:50.201000', 'guxingyu', '河南省新乡市红旗区乔谢社区', 'guxingyu', 2);
INSERT INTO `user` VALUES (23, NULL, 0, NULL, NULL, 0, '2025-04-22 07:11:51.535000', '666', NULL, '666', 0);
INSERT INTO `user` VALUES (24, '1842390194782934', 1200, '顾兴宇', '16628304583', 1, '2025-04-25 17:47:00.954000', 'guxingyu1', '河南省新乡市新乡学院', 'guxingyu1', 2);
INSERT INTO `user` VALUES (27, '1859483950748395', 0, '天翼', '19483758493', 0, '2025-04-19 09:36:57.000000', '123123', '河南省新乡市新乡学院', '123123', 1);
INSERT INTO `user` VALUES (28, '1847394730285938', 0, '六六', '18437486593', 0, '2025-04-16 09:39:01.000000', '222', '河南省新乡市新乡学院', '222', 1);
INSERT INTO `user` VALUES (29, '19483748392', 0, '钱七', '1738493875840284', 1, '2025-04-20 09:40:11.000000', '333', '河南省新乡市新乡学院', '333', 2);
INSERT INTO `user` VALUES (30, '19483764785', 0, '赵四', '19357483920', 0, '2025-04-20 09:41:39.000000', '444', '河南省新乡市新乡学院', '444', 1);

SET FOREIGN_KEY_CHECKS = 1;
