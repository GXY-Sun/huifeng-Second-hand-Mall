package com.example.scfwq.service;

import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Goods;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public interface GoodsService {
    Result markGoodsAsSold(Integer id);

    Result getGoodsByMerchantId(Integer merchantId);

    Result deleteGoods(Map<String, Integer> params);

    Result getGoodsById(Integer id);

    Result<Page<Goods>> getGoodsList(
            Integer pageNum,
            Integer pageSize,
            String name,
            String category);

    Result<String> deleteGoods(Integer id);

    Result<List<Goods>> getWxGoodsList(Integer status);

    Result<String> insertGoods(Map<String, Object> params);
    void autoOffShelfGoods();
}

