package com.example.scfwq.service;

import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Admin;
import org.springframework.stereotype.Service;

@Service
public interface AdminService {
    Result login(Admin admin);
}
