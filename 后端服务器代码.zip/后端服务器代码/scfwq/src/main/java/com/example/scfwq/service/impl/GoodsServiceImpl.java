package com.example.scfwq.service.impl;

import com.example.scfwq.service.GoodsService;
import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Goods;
import com.example.scfwq.repository.GoodsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsRepository goodsRepository;

    @Override
    public Result markGoodsAsSold(Integer id) {
        Optional<Goods> optionalGoods = goodsRepository.findById(id);
        if (!optionalGoods.isPresent()) {
            return Result.error("商品不存在");
        }
        Goods goods = optionalGoods.get();
        goods.setStatus(2); // 直接设置为2表示已售出
        goodsRepository.save(goods);
        return Result.success("商品状态更新成功");
    }

    @Override
    public Result getGoodsByMerchantId(Integer merchantId) {
        try {
            List<Goods> goodsList = goodsRepository.findByMerchantId(merchantId);
            return Result.success(goodsList);
        } catch (Exception e) {
            return Result.error("获取商品列表失败");
        }
    }

    @Override
    public Result deleteGoods(Map<String, Integer> params) {
        try {
            Integer goodsId = params.get("id");
            Goods goods = goodsRepository.findById(goodsId).orElse(null);
            if (goods == null) {
                return Result.error("商品不存在");
            }

            goodsRepository.deleteById(goodsId);
            return Result.success("删除成功");
        } catch (Exception e) {
            return Result.error("删除商品失败");
        }
    }

    @Override
    public Result getGoodsById(Integer id) {
        Goods goods = goodsRepository.findById(id).orElse(null);
        if (goods == null) {
            return Result.error("商品不存在");
        }
        return Result.success(goods);
    }

    @Override
    public Result<Page<Goods>> getGoodsList(Integer pageNum, Integer pageSize, String name, String category) {
        Pageable pageable = PageRequest.of(pageNum - 1, pageSize);
        Page<Goods> goods;

        if (name != null && category != null) {
            goods = goodsRepository.findByNameContainingAndCategory(name, category, pageable);
        } else if (name != null) {
            goods = goodsRepository.findByNameContaining(name, pageable);
        } else if (category != null) {
            goods = goodsRepository.findByCategory(category, pageable);
        } else {
            goods = goodsRepository.findAll(pageable);
        }

        System.out.println("返回的商品分页数据: " + goods);
        System.out.println("内容: " + goods.getContent());
        System.out.println("总数: " + goods.getTotalElements());
        return Result.success(goods);
    }

    @Override
    public Result<String> deleteGoods(Integer id) {
        try {
            goodsRepository.deleteById(id);
            return Result.success("商品删除成功");
        } catch (Exception e) {
            return Result.error("删除商品失败: " + e.getMessage());
        }
    }

    @Override
    public Result<List<Goods>> getWxGoodsList(Integer status) {
        List<Goods> goodsList;
        if (status != null) {
            goodsList = goodsRepository.findByStatus(status);
        } else {
//            goodsList = goodsRepository.findAll();
            return Result.error("参数错误");
        }
        return Result.success(goodsList);
    }

    @Override
    public Result<String> insertGoods(Map<String, Object> params) {
        try {
            Goods goods = new Goods();
            goods.setName((String) params.get("name"));
            goods.setDescription((String) params.get("description"));
            goods.setCategory((String) params.get("category"));
            goods.setPrice(Double.parseDouble(params.get("price").toString()));
            goods.setImageUrl((String) params.get("imageUrl"));
            goods.setMerchantId(Integer.parseInt(params.get("merchantId").toString()));

            Integer role = Integer.parseInt(params.get("role").toString());
            goods.setStatus(1); // 默认状态为已上架
            goods.setCreateTime(new Date());

            // 计算自动下架时间
            Date now = new Date();
            long offShelfTime = now.getTime();
            if (role == 0) { // 普通会员7天
                offShelfTime += 7 * 60 * 24 * 60 * 1000;
            } else { // VIP会员30天
                offShelfTime += 30 * 60 * 24 * 60 * 1000;
            }
            goods.setAutoOffShelfTime(new Date(offShelfTime));

            goodsRepository.save(goods);
            return Result.success("商品添加成功");
        } catch (Exception e) {
            return Result.error("添加商品失败: " + e.getMessage());
        }
    }
    @Override
    public void autoOffShelfGoods() {
        List<Goods> goodsList = goodsRepository.findByStatusAndAutoOffShelfTimeBefore(1, new Date());
        for (Goods goods : goodsList) {
            goods.setStatus(2); // 下架状态
            goodsRepository.save(goods);
        }
    }
}
