package com.example.scfwq.service;

import com.example.scfwq.common.Result;
import com.example.scfwq.dto.OrderDTO;
import com.example.scfwq.entity.Order;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.Map;
@Service
public interface OrderService {
    Result<String> updateOrderStatus(Map<String, String> params);
    Result refundOrder(Integer id);
    Result rejectRefund(Integer id);
    Result deleteOrder(Integer id);
    Result shipOrder(Integer id);
    Result confirmReceipt(Map<String, String> params);
    Result<Order> createOrder(Map<String, Object> params);
    Result<Page<OrderDTO>> getOrdersByPage(
            int page,
            int size,
            Integer id) ;


}
