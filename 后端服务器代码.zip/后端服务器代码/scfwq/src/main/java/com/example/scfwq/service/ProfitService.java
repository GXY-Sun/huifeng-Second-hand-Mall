package com.example.scfwq.service;

import com.example.scfwq.common.Result;
import com.example.scfwq.dto.AddProfitDTO;
import com.example.scfwq.entity.Profit;
import org.springframework.stereotype.Service;

@Service
public interface ProfitService {
    Result add(Profit profit);
    Result getById(Integer id);
    Result findPage(Integer pageNum,
                    Integer pageSize);
    Result findAll();
    Result update(Profit profit);
    Result delete(Integer id);
    Result addProfit(AddProfitDTO addProfitDTO);
}
