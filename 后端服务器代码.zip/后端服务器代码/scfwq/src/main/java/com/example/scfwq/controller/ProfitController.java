package com.example.scfwq.controller;

import com.example.scfwq.service.ProfitService;
import com.example.scfwq.common.Result;
import com.example.scfwq.dto.AddProfitDTO;
import com.example.scfwq.entity.Profit;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/profit")
public class ProfitController {
    private final ProfitService profitService;

    public ProfitController(ProfitService profitService) {
        this.profitService = profitService;
    }

    @PostMapping
    public Result add(@RequestBody Profit profit) {
        return profitService.add(profit);
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        return profitService.getById(id);
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam(defaultValue = "1") Integer pageNum,
                           @RequestParam(defaultValue = "5") Integer pageSize) {
        return profitService.findPage(pageNum, pageSize);
    }

    @GetMapping("/all")
    public Result findAll() {
        return profitService.findAll();
    }

    @PutMapping
    public Result update(@RequestBody Profit profit) {
        return profitService.update(profit);
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        return profitService.delete(id);
    }

    @PutMapping("/wx/addProfit")
    public Result addProfit(@RequestBody AddProfitDTO addProfitDTO) {
        return profitService.addProfit(addProfitDTO);
    }
}