package com.example.scfwq.repository;

import com.example.scfwq.entity.Goods;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Date;

@Repository
public interface GoodsRepository extends JpaRepository<Goods, Integer> {
    List<Goods> findByStatusAndAutoOffShelfTimeBefore(Integer status, Date date);
    Page<Goods> findByNameContaining(String name, Pageable pageable);
    Page<Goods> findByCategory(String category, Pageable pageable);
    Page<Goods> findByNameContainingAndCategory(String name, String category, Pageable pageable);

    @Modifying
    @Transactional
    @Query("UPDATE Goods g SET g.status = :status WHERE g.id = :id")
    int updateStatus(@Param("id") Integer id, @Param("status") Integer status);

    List<Goods> findByStatus(Integer status);
    
    List<Goods> findByMerchantId(Integer merchantId);
}
