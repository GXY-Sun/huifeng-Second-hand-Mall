package com.example.scfwq.service.impl;

import com.example.scfwq.service.ProfitService;
import com.example.scfwq.common.Result;
import com.example.scfwq.dto.AddProfitDTO;
import com.example.scfwq.entity.Profit;
import com.example.scfwq.repository.ProfitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
@Service
public class ProfitServiceImpl implements ProfitService {

    @Autowired
    private ProfitRepository profitRepository;

    @Override
    public Result add(Profit profit) {
        profitRepository.save(profit);
        return Result.success("操作成功");
    }

    @Override
    public Result getById(Integer id) {
        return Result.success(profitRepository.findById(id));
    }

    @Override
    public Result findPage(Integer pageNum, Integer pageSize) {
        PageRequest pageRequest = PageRequest.of(pageNum - 1, pageSize);
        Page<Profit> page = profitRepository.findAll(pageRequest);
        return Result.success(page);
    }

    @Override
    public Result findAll() {
        return Result.success(profitRepository.findAll());
    }

    @Override
    public Result update(Profit profit) {
        profitRepository.save(profit);
        return Result.success("更新成功");
    }

    @Override
    public Result delete(Integer id) {
        profitRepository.deleteById(id);
        return Result.success("删除成功");
    }

    @Override
    public Result addProfit(AddProfitDTO addProfitDTO) {
        Integer orderId = addProfitDTO.getOrderId();
        Double amount = addProfitDTO.getAmount();
        Profit profit = new Profit();
        profit.setOrderId(orderId);
        profit.setAmount(amount * 0.01);
        profit.setProfitTime(LocalDateTime.now());
        profitRepository.save(profit);
        return Result.success("利润记录添加成功");
    }
}
