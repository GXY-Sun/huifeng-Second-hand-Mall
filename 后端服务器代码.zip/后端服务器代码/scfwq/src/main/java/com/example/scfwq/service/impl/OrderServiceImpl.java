package com.example.scfwq.service.impl;

import com.example.scfwq.service.OrderService;
import com.example.scfwq.common.Result;
import com.example.scfwq.dto.OrderDTO;
import com.example.scfwq.entity.Goods;
import com.example.scfwq.entity.Order;
import com.example.scfwq.entity.User;
import com.example.scfwq.repository.GoodsRepository;
import com.example.scfwq.repository.OrderRepository;
import com.example.scfwq.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private GoodsRepository goodsRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Result<String> updateOrderStatus(Map<String, String> params) {
        String orderId = params.get("id");
        String statusStr = params.get("status");
        if (statusStr == null) {
            return Result.error("缺少状态参数");
        }

        int status;
        try {
            status = Integer.parseInt(statusStr);
        } catch (NumberFormatException e) {
            return Result.error("状态参数格式错误");
        }

        Order order = orderRepository.findById(Integer.parseInt(orderId)).orElse(null);
        if (order == null) {
            return Result.error("订单不存在");
        }

        // 状态校验
        if (status == 3 && order.getStatus() >= 3) {
            return Result.error("订单已完成");
        }
        if (status == 2 && order.getStatus() != 1) {
            return Result.error("只有待收货订单可以申请退款");
        }

        order.setStatus(status);
        orderRepository.save(order);
        return Result.success(status == 3 ? "确认收货成功" : "申请退款成功");
    }

    @Override
    @Transactional
    public Result rejectRefund(Integer id) {
        try {
            Order order = orderRepository.findById(id).orElse(null);
            if (order == null) {
                return Result.error("订单不存在");
            }

            if (order.getStatus() != 2) {
                return Result.error("只有待退款订单可以拒绝退款");
            }

            // 更新订单状态为待收货(1)
            order.setStatus(1);
            orderRepository.save(order);
            return Result.success("拒绝退款成功");
        } catch (Exception e) {
            return Result.error("拒绝退款失败: " + e.getMessage());
        }
    }

    @Override
    @Transactional
    public Result refundOrder(Integer id) {
        try {
            Order order = orderRepository.findById(id).orElse(null);
            if (order == null) {
                return Result.error("订单不存在");
            }

            if (order.getStatus() != 2) {
                return Result.error("只有待收货订单可以申请退款");
            }

            // 更新订单状态为已完成
            order.setStatus(3);
            orderRepository.save(order);

            // 获取商品信息
            Goods goods = goodsRepository.findById(order.getGoodsId()).orElse(null);
            if (goods == null) {
                return Result.error("商品不存在");
            }

            // 获取用户信息
            User user = userRepository.findById(order.getUserId()).orElse(null);
            if (user == null) {
                return Result.error("用户不存在");
            }

            // 计算退款金额
            double refundAmount = goods.getPrice();

            // 更新用户余额
            user.setMoney(user.getMoney() + refundAmount);
            userRepository.save(user);

            return Result.success("退款成功");
        } catch (Exception e) {
            return Result.error("退款失败: " + e.getMessage());
        }
    }

    @Override
    public Result deleteOrder(Integer id) {
        try {
            Order order = orderRepository.findById(id).orElse(null);
            if (order == null) {
                return Result.error("订单不存在");
            }

            if (order.getStatus() != 3) {
                return Result.error("只有已完成订单可以删除");
            }

            orderRepository.deleteById(id);
            return Result.success("删除成功");
        } catch (Exception e) {
            return Result.error("删除失败: " + e.getMessage());
        }
    }

    @Override
    public Result shipOrder(Integer id) {
        try {
            int updated = orderRepository.updateOrderStatus(id, 1); // 1表示待收货状态
            if (updated > 0) {
                return Result.success("发货成功");
            }
            return Result.error("发货失败，订单不存在或状态异常");
        } catch (Exception e) {
            return Result.error("发货操作失败: " + e.getMessage());
        }
    }

    @Override
    public Result confirmReceipt(Map<String, String> params) {
        try {
            Integer orderId = Integer.parseInt(params.get("orderId"));
            Order order = orderRepository.findById(orderId).orElse(null);
            if (order == null) {
                return Result.error("订单不存在");
            }

            // 获取商品信息
            Goods goods = goodsRepository.findById(order.getGoodsId()).orElse(null);
            if (goods == null) {
                return Result.error("商品不存在");
            }

            // 获取卖家信息
            User merchant = userRepository.findById(goods.getMerchantId()).orElse(null);
            if (merchant == null) {
                return Result.error("卖家不存在");
            }

            // 计算卖家应得金额(商品价格的99%)
            double amount = goods.getPrice() * 0.99;

            // 更新卖家余额
            merchant.setMoney(merchant.getMoney() + amount);
            userRepository.save(merchant);

            // 更新订单状态为已完成(3)
            order.setStatus(3);
            orderRepository.save(order);

            return Result.success("确认收货成功");
        } catch (Exception e) {
            return Result.error("确认收货失败: " + e.getMessage());
        }
    }

    @Override
    public Result<Order> createOrder(Map<String, Object> params) {
        Integer userId = (Integer) params.get("userId");
        Integer goodsId = (Integer) params.get("goodsId");

        // 验证商品是否存在
        Goods goods = goodsRepository.findById(goodsId).orElse(null);
        if (goods == null) {
            return Result.error("商品不存在");
        }

        // 创建新订单
        Order order = new Order();
        order.setUserId(userId);
        order.setGoodsId(goodsId);
        order.setOrderTime(LocalDateTime.now());
        order.setStatus(0); // 0表示待发货

        Order savedOrder = orderRepository.save(order);
        return Result.success(savedOrder);
    }

    @Override
    public Result<Page<OrderDTO>> getOrdersByPage(int page, int size, Integer id) {
        PageRequest pageRequest = PageRequest.of(page - 1, size);
        Page<Order> orderPage = id != null ?
                orderRepository.findById(id, pageRequest) :
                orderRepository.findAll(pageRequest);

        // 转换为DTO并填充额外数据
        Page<OrderDTO> dtoPage = orderPage.map(order -> {
            OrderDTO dto = new OrderDTO();
            dto.setId(order.getId());
            dto.setUserId(order.getUserId());
            dto.setGoodsId(order.getGoodsId());
            dto.setOrderTime(order.getOrderTime());
            dto.setStatus(order.getStatus());

            // 获取用户地址
            User user = userRepository.findById(order.getUserId()).orElse(null);
            if (user != null) {
                dto.setAddress(user.getAddress());
            }

            // 获取商品价格
            Goods goods = goodsRepository.findById(order.getGoodsId()).orElse(null);
            if (goods != null) {
                dto.setPrice(goods.getPrice());
            }
            return dto;
        });

        return Result.success(dtoPage);
    }
}
