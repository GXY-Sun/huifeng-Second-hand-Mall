package com.example.scfwq.controller;

import com.example.scfwq.service.UserService;
import com.example.scfwq.common.Result;
import com.example.scfwq.entity.User;
import com.example.scfwq.entity.Order;

import java.util.Map;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "用户管理")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("分页获取用户列表")
    @GetMapping("/list")
    public Result<Page<User>> getAllUsers(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "5") Integer pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Integer role) {
        return userService.getAllUsers(pageNum, pageSize, name, role);
    }

    @ApiOperation("获取VIP申请列表")
    @GetMapping("/vip-apply-list")
    public Result<Page<User>> getVipApplyList(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "5") Integer pageSize,
            @RequestParam(required = false) Integer id) {
        return userService.getVipApplyList(pageNum, pageSize, id);
    }

    @ApiOperation("同意VIP申请")
    @PostMapping("/approve-vip/{id}")
    public Result<User> approveVipApply(@PathVariable Integer id) {
        return userService.approveVipApply(id);
    }

    @ApiOperation("拒绝VIP申请")
    @PostMapping("/reject-vip/{id}")
    public Result<User> rejectVipApply(@PathVariable Integer id) {
        return userService.rejectVipApply(id);
    }

    // 保留原有其他方法...
    @ApiOperation("根据ID删除用户")
    @DeleteMapping("/delete/{id}")
    public Result<String> deleteUser(@PathVariable Integer id) {
        return userService.deleteUser(id);
    }

    @ApiOperation("用户登录")
    @PostMapping("/login")
    public Result<User> login(@RequestBody User user) {
        return userService.login(user);
    }

    @ApiOperation("检查账号是否存在")
    @PostMapping("/wx/check")
    public Result<Boolean> checkAccount(@RequestBody User user) {
        return userService.checkAccount(user);
    }

    @ApiOperation("用户注册")
    @PostMapping("/wx/register")
    public Result<String> register(@RequestBody User user) {
        return userService.register(user);
    }

    @ApiOperation("更新用户个人信息")
    @PostMapping("/wx/updateUserInfo")
    public Result<User> updateUserInfo(@RequestBody User user) {
        return userService.updateUserInfo(user);
    }

    @ApiOperation("根据用户ID获取订单")
    @GetMapping("/wx/getOrdersByUserId")
    public Result<List<Order>> getOrdersByUserId(@RequestParam Integer id) {
        return userService.getOrdersByUserId(id);
    }

    @ApiOperation("申请VIP会员")
    @PostMapping("/wx/applyVip")
    public Result<User> applyVip(@RequestBody Map<String, Object> params) {
        return userService.applyVip(params);
    }

    @ApiOperation("全额提现")
    @PostMapping("/wx/withdrawAll")
    public Result<User> withdrawAll(@RequestBody Map<String, Object> params) {
        return userService.withdrawAll(params);
    }

    @ApiOperation("用户充值")
    @PostMapping("/wx/recharge")
    public Result<User> recharge(@RequestBody Map<String, Object> params) {
        return userService.recharge(params);
    }

    @ApiOperation("更新用户余额")
    @PostMapping("/wx/updateBalance")
    public Result<User> updateBalance(@RequestBody Map<String, Object> params) {
        return userService.updateBalance(params);
    }

    @ApiOperation("根据ID获取用户信息")
    @GetMapping("/wx/getUserById")
    public Result<User> getUserById(@RequestParam Integer id) {
        return userService.getUserById(id);
    }
}
