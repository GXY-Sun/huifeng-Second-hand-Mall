package com.example.scfwq.controller;

import com.example.scfwq.service.GoodsService;
import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Goods;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

@Api(tags = "商品管理")
@RestController
@RequestMapping("/goods")
public class GoodsController {
    @Autowired
    private GoodsService goodsService;


    @PutMapping("/wx/sold/{id}")
    public Result markGoodsAsSold(@PathVariable Integer id) {
        return goodsService.markGoodsAsSold(id);
    }

    @GetMapping("/wx/getGoodsByMerchantId")
    public Result getGoodsByMerchantId(@RequestParam Integer merchantId) {
        return goodsService.getGoodsByMerchantId(merchantId);
    }

    @PostMapping("/wx/deleteGoods")
    public Result deleteGoods(@RequestBody Map<String, Integer> params) {
        return goodsService.deleteGoods(params.get("id"));
    }

    @GetMapping("/wx/getGoodsById")
    public Result getGoodsById(@RequestParam Integer id) {
        return goodsService.getGoodsById(id);
    }

    @ApiOperation("分页获取商品列表")
    @GetMapping("/list")
    public Result<Page<Goods>> getGoodsList(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "5") Integer pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String category) {
        return goodsService.getGoodsList(pageNum, pageSize, name, category);
    }

    @ApiOperation("删除商品")
    @DeleteMapping("/delete/{id}")
    public Result<String> deleteGoods(@PathVariable Integer id) {
        return goodsService.deleteGoods(id);
    }
//
//    @ApiOperation("审核上架商品")
//    @PutMapping("/approve/{id}")
//    public Result<String> approveGoods(@PathVariable Integer id) {
//        try {
//            int updated = goodsRepository.updateStatus(id, 1);
//            if (updated == 0) {
//                return Result.error("商品不存在");
//            }
//            return Result.success("商品上架成功");
//        } catch (Exception e) {
//            return Result.error("上架失败: " + e.getMessage());
//        }
//    }

    @ApiOperation("微信端获取商品列表")
    @GetMapping("/wx/list")
    public Result<List<Goods>> getWxGoodsList(@RequestParam(required = false) Integer status) {
        return goodsService.getWxGoodsList(status);
    }

    @ApiOperation("微信端添加商品")
    @PostMapping("/wx/insertgoods")
    public Result<String> insertGoods(@RequestBody Map<String, Object> params) {
        return goodsService.insertGoods(params);
    }

    @Scheduled(fixedRate = 3600000) // 一小时检查一次
    public void autoOffShelfGoods() {
        goodsService.autoOffShelfGoods();
    }

}
