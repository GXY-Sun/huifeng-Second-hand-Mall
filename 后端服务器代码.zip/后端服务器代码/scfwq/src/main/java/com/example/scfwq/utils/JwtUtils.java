package com.example.scfwq.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;
import java.util.Map;

public class JwtUtils {
    // 签名密钥20214004021guxingyu的二手物品商城（64编码前）
    private static final String signKey = "MjAyMTQwMDQwMjFndXhpbmd5deeahOS6jOaJi+eJqeWTgeWVhuWfjg==";
    // 过期时间1小时(毫秒)
    private static final Long expire = 3600000L;

    /**
     * 生成JWT令牌
     * @param claims JWT第二部分负载 payload 中存储的内容
     * @return JWT字符串
     */
    public static String generateJwt(Map<String, Object> claims) {
        return Jwts.builder()
                .addClaims(claims) // 自定义信息（有效载荷）
                .signWith(SignatureAlgorithm.HS256, signKey) // 签名算法和密钥
                .setExpiration(new Date(System.currentTimeMillis() + expire)) // 过期时间
                .compact();
    }

    /**
     * 解析JWT令牌
     * @param jwt JWT字符串
     * @return JWT第二部分负载 payload 中存储的内容
     */
    public static Claims parseJWT(String jwt) {
        return Jwts.parser()
                .setSigningKey(signKey) // 指定签名密钥
                .parseClaimsJws(jwt) // 解析令牌
                .getBody();
    }
}
