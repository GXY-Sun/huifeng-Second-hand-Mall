package com.example.scfwq.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "`order`") // 使用反引号避免与SQL关键字冲突
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id; // 订单号
    @Column(name = "user_id")
    private Integer userId; // 用户ID
    
    @Column(name = "goods_id")
    private Integer goodsId; // 商品ID
    private LocalDateTime orderTime; // 下单时间
    private Integer status; // 订单状态: 0-待发货,1-待收货,2-待退款,3-已完成

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
