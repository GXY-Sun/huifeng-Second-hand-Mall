package com.example.scfwq.controller;


import com.example.scfwq.service.AdminService;
import com.example.scfwq.entity.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.scfwq.common.Result;

@RestController
@RequestMapping("/api/admin")
//@CrossOrigin(origins = {"http://localhost:8081", "http://localhost:8082"})
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public Result login(@RequestBody Admin admin) {
        return adminService.login(admin);
    }
}
