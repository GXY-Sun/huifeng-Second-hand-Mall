package com.example.scfwq.service.impl;

import com.example.scfwq.service.AdminService;
import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Admin;
import com.example.scfwq.repository.AdminRepository;
import com.example.scfwq.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;
    @Override
    public Result login(Admin admin) {
        Admin dbAdmin = adminRepository.findByAdusernameAndAdpassword(admin.getAdusername(),admin.getAdpassword());
        if (dbAdmin != null) {
            // 生成JWT令牌
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", dbAdmin.getAdid());
            claims.put("username", dbAdmin.getAdusername());
            String token = JwtUtils.generateJwt(claims);

            // 返回令牌和用户信息
            Map<String, Object> result = new HashMap<>();
            result.put("token", token);
            result.put("admin", dbAdmin);
            return Result.success(result);
        }
        return Result.error("用户名或密码错误");
    }
}
