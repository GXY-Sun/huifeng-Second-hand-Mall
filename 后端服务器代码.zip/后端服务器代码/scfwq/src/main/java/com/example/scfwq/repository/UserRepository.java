package com.example.scfwq.repository;

import com.example.scfwq.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    // 根据昵称模糊查询(分页)
    Page<User> findByNameContaining(String name, Pageable pageable);
    
    // 根据会员等级查询(分页)
    Page<User> findByRole(Integer role, Pageable pageable);
    
    // 根据昵称模糊查询和会员等级查询(分页)
    Page<User> findByNameContainingAndRole(String name, Integer role, Pageable pageable);
    
    // 根据账号和密码查询
    User findByAccountAndPassword(String account, String password);
    
    // 根据账号查询
    User findByAccount(String account);
    
    // 根据申请状态和会员等级查询(分页)
    Page<User> findByApplyAndRole(Integer apply, Integer role, Pageable pageable);
    
    // 根据ID模糊查询、申请状态和会员等级查询(分页)
    Page<User> findByIdContainingAndApplyAndRole(String id, Integer apply, Integer role, Pageable pageable);
    
    // 根据ID、申请状态和会员等级查询(分页)
    Page<User> findByIdAndApplyAndRole(Integer id, Integer apply, Integer role, Pageable pageable);
}
