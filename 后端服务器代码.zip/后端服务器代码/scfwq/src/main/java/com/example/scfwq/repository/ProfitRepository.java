package com.example.scfwq.repository;

import com.example.scfwq.entity.Profit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfitRepository extends JpaRepository<Profit, Integer> {
}
