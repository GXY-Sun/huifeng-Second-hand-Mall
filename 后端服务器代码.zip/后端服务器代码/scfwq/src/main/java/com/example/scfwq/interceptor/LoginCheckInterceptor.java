package com.example.scfwq.interceptor;

import com.example.scfwq.common.Result;
import com.example.scfwq.utils.JwtUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LoginCheckInterceptor implements HandlerInterceptor {
    @Override //目标资源方法运行前运行, 返回true: 放行, 放回false, 不放行
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) throws Exception {
        //1.获取请求url。
        String url = req.getRequestURL().toString();


        //2.判断请求url中是否包含login或/wx/，如果包含，说明是登录操作或小程序请求，放行。
        if(url.contains("login") || url.contains("wx")){
            return true;
        }
        System.out.println("已拦截");
        //3.获取请求头中的令牌（token）。
        String jwt = req.getHeader("token");

        //4.判断令牌是否存在，如果不存在，返回错误结果（未登录）。
        if(jwt == null || jwt.isEmpty()){
            resp.setStatus(401);
            return false;
        }

        //5.解析token，如果解析失败，返回错误结果（未登录）。
        try {
            JwtUtils.parseJWT(jwt);
        } catch (Exception e) {//jwt解析失败
            resp.setStatus(401);
            return false;
        }

        //6.放行。

        return true;
    }

}
