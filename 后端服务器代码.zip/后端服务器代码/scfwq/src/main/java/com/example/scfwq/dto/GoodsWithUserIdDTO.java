package com.example.scfwq.dto;

import com.example.scfwq.entity.Goods;

public class GoodsWithUserIdDTO {
    private Goods goods;
    private Integer role; // 0-普通会员1分钟 1-vip5分钟

    public Goods getGoods() {
        return goods;
    }

    public void setGoods(Goods goods) {
        this.goods = goods;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }
}
