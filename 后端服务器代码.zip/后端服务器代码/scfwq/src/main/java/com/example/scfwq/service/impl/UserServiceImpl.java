package com.example.scfwq.service.impl;

import com.example.scfwq.service.UserService;
import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Order;
import com.example.scfwq.entity.User;
import com.example.scfwq.repository.OrderRepository;
import com.example.scfwq.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Result<Page<User>> getAllUsers(Integer pageNum, Integer pageSize, String name, Integer role) {
        Pageable pageable = PageRequest.of(pageNum - 1, pageSize);
        Page<User> users;

        if (name != null && role != null) {
            users = userRepository.findByNameContainingAndRole(name, role, pageable);
        } else if (name != null) {
            users = userRepository.findByNameContaining(name, pageable);
        } else if (role != null) {
            users = userRepository.findByRole(role, pageable);
        } else {
            users = userRepository.findAll(pageable);
        }

        return Result.success(users);
    }

    @Override
    public Result<Page<User>> getVipApplyList(Integer pageNum, Integer pageSize, Integer id) {
        Pageable pageable = PageRequest.of(pageNum - 1, pageSize);
        Page<User> users;

        if (id != null) {
            users = userRepository.findByIdAndApplyAndRole(id, 1, 0, pageable);
        } else {
            users = userRepository.findByApplyAndRole(1, 0, pageable);
        }
        return Result.success(users);
    }

    @Override
    public Result<User> approveVipApply(Integer id) {
        User user = userRepository.findById(id).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }
        if (user.getApply() != 1 || user.getRole() != 0) {
            return Result.error("该用户没有VIP申请");
        }

        user.setRole(1); // 设置为VIP
        user.setApply(2); // 设置无法申请
        userRepository.save(user);

        return Result.success(user);
    }

    @Override
    public Result<User> rejectVipApply(Integer id) {
        User user = userRepository.findById(id).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }
        if (user.getApply() != 1 || user.getRole() != 0) {
            return Result.error("该用户没有VIP申请");
        }

        user.setApply(0); // 设置未申请
        userRepository.save(user);

        return Result.success(user);
    }

    // 保留原有其他方法...


    @Override
    public Result<String> deleteUser(Integer id) {
        userRepository.deleteById(id);
        return Result.success("用户删除成功");
    }

    @Override
    public Result<User> login(User user) {
        User dbUser = userRepository.findByAccountAndPassword(user.getAccount(), user.getPassword());
        if (dbUser == null) {
            return Result.error("账号或密码错误");
        }
        return Result.success(dbUser);
    }

    @Override
    public Result<Boolean> checkAccount(User user) {
        User existingUser = userRepository.findByAccount(user.getAccount());
        return Result.success(existingUser != null);
    }

    @Override
    public Result<String> register(User user) {
        user.setRole(0);
        user.setTime(LocalDateTime.now());
        user.setMoney(0.0);
        user.setApply(0);
        userRepository.save(user);
        return Result.success("注册成功");
    }

    @Override
    public Result<User> updateUserInfo(User user) {
        Optional<User> existingUser = userRepository.findById(user.getId());
        if (!existingUser.isPresent()) {
            return Result.error("用户不存在");
        }

        User dbUser = existingUser.get();
        if (user.getName() != null) dbUser.setName(user.getName());
        if (user.getPhone() != null) dbUser.setPhone(user.getPhone());
        if (user.getCard() != null) dbUser.setCard(user.getCard());
        if (user.getAddress() != null) dbUser.setAddress(user.getAddress());

        userRepository.save(dbUser);
        return Result.success(dbUser);
    }

    @Override
    public Result<List<Order>> getOrdersByUserId(Integer id) {
        List<Order> orders = orderRepository.findByUserId(id);
        return Result.success(orders != null ? orders : Collections.emptyList());
    }


    @Override
    public Result<User> applyVip(Map<String, Object> params) {
        Integer userId = (Integer) params.get("userId");
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }
        if (user.getRole() == 1) {
            return Result.error("已经是VIP了");
        }
        if (user.getApply() == 1) {
            return Result.error("已申请过了");
        }

        user.setApply(1);
        return Result.success(userRepository.save(user));
    }

    @Override
    public Result<User> withdrawAll(Map<String, Object> params) {
        Integer userId = (Integer) params.get("userId");
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }

        user.setMoney(0.0);
        return Result.success(userRepository.save(user));
    }

    @Override
    public Result<User> recharge(Map<String, Object> params) {
        Integer userId = (Integer) params.get("userId");
        Double amount = Double.parseDouble(params.get("amount").toString());
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }
        if (amount <= 0) {
            return Result.error("充值金额必须大于0");
        }

        user.setMoney(user.getMoney() + amount);
        return Result.success(userRepository.save(user));
    }

    @Override
    public Result<User> updateBalance(Map<String, Object> params) {
        try {
            Integer userId = (Integer) params.get("userId");
            Double price = Double.parseDouble(params.get("price").toString());
            User user = userRepository.findById(userId).orElse(null);
            if (user == null) {
                return Result.error("用户不存在");
            }
            if (price <= 0) {
                return Result.error("商品价格必须大于0");
            }
            if (user.getMoney() < price) {
                return Result.error("余额不足");
            }

            user.setMoney(user.getMoney() - price);
            return Result.success(userRepository.save(user));
        } catch (Exception e) {
            return Result.error("系统错误: " + e.getMessage());
        }
    }

    @Override
    public Result<User> getUserById(Integer id) {
        User user = userRepository.findById(id).orElse(null);
        if (user == null) {
            return Result.error("用户不存在");
        }
        return Result.success(user);
    }
}
