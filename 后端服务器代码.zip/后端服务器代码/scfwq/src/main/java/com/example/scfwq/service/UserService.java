package com.example.scfwq.service;

import com.example.scfwq.common.Result;
import com.example.scfwq.entity.Order;
import com.example.scfwq.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public interface UserService {
    Result<Page<User>> getAllUsers(
            Integer pageNum,
            Integer pageSize,
            String name,
            Integer role);
    Result<Page<User>> getVipApplyList(
            Integer pageNum,
            Integer pageSize,
            Integer id);
    Result<User> approveVipApply(Integer id);
    Result<User> rejectVipApply(Integer id);
    Result<String> deleteUser(Integer id);
    Result<User> login(User user);
    Result<Boolean> checkAccount(User user);
    Result<String> register(User user);
    Result<User> updateUserInfo(User user);
    Result<List<Order>> getOrdersByUserId(Integer id);
    Result<User> applyVip(Map<String, Object> params);
    Result<User> withdrawAll(Map<String, Object> params);
    Result<User> recharge(Map<String, Object> params);
    Result<User> updateBalance(Map<String, Object> params);
    
    Result<User> getUserById(Integer id);
}
